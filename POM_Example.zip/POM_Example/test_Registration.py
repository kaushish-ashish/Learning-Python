from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from RegistrationPageObjects import RegistrationPage

class TestRegistration:
    def test_registration(self):
        serv_obj = Service(ChromeDriverManager().install())
        self.driver=webdriver.Chrome(service=serv_obj)
        self.driver.get("https://vinothqaacademy.com/demo-site/")
        self.driver.maximize_window()

        self.rp=RegistrationPage(self.driver)
        self.rp.set_firstname("Ashish")
        self.rp.set_lastname("Sharma")
        self.rp.set_gender()
        self.rp.set_email("ashish@yopmail.com")
        self.rp.set_verification(77)
        self.rp.scroll_to_bottom()
        self.rp.click_submit()
        self.act_title = self.driver.title
        self.driver.close()
        assert self.act_title == "Demo Site – Transaction Id – Vinoth Tech Solutions"
        self.driver.quit()