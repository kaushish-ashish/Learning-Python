import time

from selenium.webdriver.common.by import By

class RegistrationPage:

    # Locators
    txtbox_first_name_id = "vfb-5"
    txtbox_last_name_id = "vfb-7"
    radiobtn_gender_name = "vfb-31"
    txtbox_email_id = "vfb-14"
    txtbox_verification_id = "vfb-3"
    btn_submit_id ="vfb-4"
    txt_title_xpath = "//h2[normalize-space()='Transaction Details']"

    # Constructor
    def __init__(self, driver):
        self.driver = driver

    # ------------------ Common Utility ------------------
    def scroll_to_element(self, element):
        self.driver.execute_script(
            "arguments[0].scrollIntoView({behavior:'smooth', block:'bottom'});",
            element
        )

    def scroll_to_bottom(self):
        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

    # ------------------ Action Methods ------------------
    def set_firstname(self, f_name):
        firstname = self.driver.find_element(By.ID, self.txtbox_first_name_id)
        self.scroll_to_element(firstname)
        firstname.send_keys(f_name)

    def set_lastname(self, l_name):
        lastname = self.driver.find_element(By.ID, self.txtbox_last_name_id)
        self.scroll_to_element(lastname)
        lastname.send_keys(l_name)

    def set_gender(self):
        options = ["Male", "Female", "Other"]

        for option in options:
            radio = self.driver.find_element(By.XPATH, f"//label[normalize-space()='{option}']/preceding-sibling::input")
            self.scroll_to_element(radio)
            self.driver.execute_script("arguments[0].click();", radio)

    def set_email(self, email_id):
        email = self.driver.find_element(By.ID, self.txtbox_email_id)
        self.scroll_to_element(email)
        email.send_keys(email_id)

    def set_verification(self, verification_id):
        verification_txt=self.driver.find_element(By.ID, self.txtbox_verification_id)
        self.scroll_to_element(verification_txt)
        verification_txt.send_keys(verification_id)
        time.sleep(1)

    def click_submit(self):
        submit_btn = self.driver.find_element(By.ID, self.btn_submit_id)
        submit_btn.click()
