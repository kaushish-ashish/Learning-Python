from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options

chrome_options = Options()
chrome_options.add_argument("--disable-notifications")

# Initialize driver with options
driver = webdriver.Chrome(
    service=ChromeService(ChromeDriverManager().install()),
    options=chrome_options
)

driver.implicitly_wait(10)

driver.get("https://jqueryui.com/droppable/")
driver.maximize_window()

act=ActionChains(driver)

iframe = driver.find_element(By.CLASS_NAME, "demo-frame")
driver.switch_to.frame(iframe)  # switching to frame

from_ele=driver.find_element(By.ID,"draggable")
to_ele=driver.find_element(By.ID,"droppable")
act.drag_and_drop(from_ele,to_ele).perform()  # drag and drop operation

driver.switch_to.default_content()

driver.quit()
