import time

from selenium import webdriver
from selenium.webdriver import ActionChains
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options

chrome_options = Options()
chrome_options.add_argument("--disable-notifications")

# Initialize driver with options
driver = webdriver.Chrome(
    service=ChromeService(ChromeDriverManager().install()),
    options=chrome_options
)

driver.implicitly_wait(10)

driver.get("https://testautomationpractice.blogspot.com/")
driver.maximize_window()

#Login
# driver.find_element(By.XPATH,"//input[@placeholder='Username']").send_keys("Admin")
# driver.find_element(By.XPATH,"//input[@placeholder='Password']").send_keys("admin123")
# driver.find_element(By.TAG_NAME,"button").click()
# time.sleep(3)

#Admin-->user management-->users
point_me_ele=driver.find_element(By.XPATH,"//button[normalize-space()='Point Me']")
mobiles_ele=driver.find_element(By.XPATH,"//a[normalize-space()='Mobiles']")
laptops_ele=driver.find_element(By.XPATH,"//a[normalize-space()='Laptops']")

#scrollIntoView
element = driver.find_element(By.XPATH, "//h2[normalize-space()='Mouse Hover']")
driver.execute_script("arguments[0].scrollIntoView();", element)

#MoseHover
act=ActionChains(driver)

act.move_to_element(point_me_ele).move_to_element(mobiles_ele).move_to_element(laptops_ele).click().perform()
time.sleep(3)
driver.quit()


