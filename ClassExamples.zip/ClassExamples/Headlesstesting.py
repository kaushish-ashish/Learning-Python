from selenium import webdriver

from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options as ChromeOptions
from webdriver_manager.chrome import ChromeDriverManager

from selenium.webdriver.edge.service import Service as EdgeService
from selenium.webdriver.edge.options import Options as EdgeOptions

from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from webdriver_manager.firefox import GeckoDriverManager

def headless_chrome():
    chrome_options = ChromeOptions()
    chrome_options.add_argument("--disable-notifications")
    chrome_options.add_argument("--headless=new")   # Modern headless
    chrome_options.add_argument("--start-maximized")

    driver = webdriver.Chrome(
        service=ChromeService(ChromeDriverManager().install()),
        options=chrome_options
    )

    driver.implicitly_wait(10)
    return driver

def headless_edge():
    edge_options = EdgeOptions()
    edge_options.add_argument("--headless=new")
    edge_options.add_argument("--disable-notifications")
    edge_options.add_argument("--disable-gpu")
    edge_options.add_argument("--window-size=1920,1080")
    edge_options.add_argument("--no-sandbox")

    service = EdgeService("C:/drivers/msedgedriver.exe")

    driver = webdriver.Edge(
        service=service,
        options=edge_options
    )

    driver.implicitly_wait(10)
    return driver


#
def headless_firefox():
    firefox_options = FirefoxOptions()
    firefox_options.add_argument("--headless")
    firefox_options.add_argument("--width=1920")
    firefox_options.add_argument("--height=1080")

    driver = webdriver.Firefox(
        service=FirefoxService(GeckoDriverManager().install()),
        options=firefox_options
    )

    driver.implicitly_wait(10)
    return driver

# driver=headless_chrome()
# driver=headless_edge()
driver=headless_firefox()


driver.get("https://demo.nopcommerce.com/")
print(driver.title)
print(driver.current_url)
driver.close()