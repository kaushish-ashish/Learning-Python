def fly():
    print("Animal can't fly")

def color():
    print("Animal is black")