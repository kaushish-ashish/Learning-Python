def add(num1,num2):
    print(num1+num2)

def mul(num1,num2):
    print(num1*num2)

# add(100,200)
# mul(10,20)
