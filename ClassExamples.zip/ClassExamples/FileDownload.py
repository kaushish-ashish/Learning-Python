import time

from selenium import webdriver
from selenium.webdriver.common.by import By
import os

# Chrome
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options as ChromeOptions, Options
from webdriver_manager.chrome import ChromeDriverManager

# Edge
from selenium.webdriver.edge.service import Service as EdgeService
from selenium.webdriver.edge.options import Options as EdgeOptions
from webdriver_manager.microsoft import EdgeChromiumDriverManager

# Firefox
from selenium.webdriver.firefox.service import Service as FirefoxService
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from webdriver_manager.firefox import GeckoDriverManager

location=os.getcwd()

def chrome_setup():
    chrome_options = Options()
    chrome_options.add_argument("--disable-notifications")

    #download files in desired location
    preferences={"download.default_directory":location}
    chrome_options.add_experimental_option("prefs", preferences)
    driver = webdriver.Chrome(
        service=ChromeService(ChromeDriverManager().install()),
        options=chrome_options
    )

    driver.implicitly_wait(10)
    driver.maximize_window()
    return driver

def edge_setup():
    edge_options = Options()
    edge_options.add_argument("--disable-notifications")

    edge_options.add_experimental_option("prefs",{
            "download.default_directory": location,
            "download.prompt_for_download": False,
            "plugins.always_open_pdf_externally": True
        }
    )

    service = EdgeService("C:/drivers/msedgedriver.exe")

    driver = webdriver.Edge(
        service=service,
        options=edge_options
    )

    driver.implicitly_wait(20)
    driver.maximize_window()
    return driver


def firefox_setup():
    firefox_options = Options()
    firefox_options.set_preference("dom.webnotifications.enabled", False)

    # Download preferences
    firefox_options.set_preference("browser.download.folderList", 2) # 0-Desktop, 1-Downloads, 2-Custom location
    firefox_options.set_preference("browser.download.dir", location)
    firefox_options.set_preference("browser.download.manager.showWhenStarting", False)
    firefox_options.set_preference("browser.helperApps.neverAsk.saveToDisk", "application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document")


    driver = webdriver.Firefox(
        service=FirefoxService(GeckoDriverManager().install()),
        options=firefox_options
    )

    driver.implicitly_wait(10)
    driver.maximize_window()
    return driver

#Automation code
driver=chrome_setup()
# driver=edge_setup()
#driver=firefox_setup()

driver.get("https://filesamples.com/formats/doc")
driver.maximize_window()

element = driver.find_element(By.XPATH, "//div[@class='output']//div[1]//a[1]")
driver.execute_script("arguments[0].scrollIntoView();", element)

time.sleep(5)
driver.find_element(By.XPATH,"(//a[@class='btn btn-blue col-span-3 md:col-span-1'])[1]").click()

driver.quit()
