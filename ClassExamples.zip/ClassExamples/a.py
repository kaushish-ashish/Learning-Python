class Animal:
    def display(self):
        print("I like cow")



