import pytest
from selenium import webdriver
from selenium.webdriver.firefox.service import Service as FirefoxService

from webdriver_manager.chrome import ChromeDriverManager
from webdriver_manager.firefox import GeckoDriverManager


@pytest.fixture()
def setup(browser):
    if browser == "chrome":
        from selenium.webdriver.chrome.service import Service
        serv_obj = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=serv_obj)
    elif browser == "edge":
        from selenium.webdriver.edge.service import Service
        serv_obj = Service("C:/drivers/msedgedriver.exe")
        driver = webdriver.Edge(service=serv_obj)
    elif browser == "firefox":
        service = FirefoxService(GeckoDriverManager().install())
        driver = webdriver.Firefox(service=service)

    else:
        raise ValueError("Unsupported browser! Use chrome / edge / firefox")

    driver.maximize_window()
    driver.implicitly_wait(15)
    yield driver

    driver.quit()

def pytest_addoption(parser):    # This will get the value from CLI
    parser.addoption("--browser", action="store",default="chrome",help="Browser to run tests: chrome / edge / firefox")

@pytest.fixture()
def browser(request):       # This will return the Browser value to setup method
    return request.config.getoption("--browser")

# It is hook for delete/Modify Environment info to HTML Report
@pytest.hookimpl(optionalhook=True)
def pytest_metadata(metadata):
    metadata.pop("Python", None)
    metadata.pop("Platform", None)
    metadata.pop("Packages", None)
    metadata.pop("Plugins", None)

# customizing reHTML Report
# It is hook for Adding Environment info to HTML Report
@pytest.hookimpl(optionalhook=True)
def pytest_metadata(metadata):
    metadata.clear()  # optional, but keeps report clean
    metadata["Project Name"] = "Orange HRM"
    metadata["Module Name"] = "Login Module"
    metadata["Tester Name"] = "Ashish"

