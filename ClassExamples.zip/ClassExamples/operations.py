#Appraoch1
# import calculator
# calculator.add(100,200)
# calculator.mul(10,20)

#Appraoch2
from calculator import add,mul
add(100,200)
mul(10,20)

#Appraoch3
from calculator import *
add(100,200)
mul(10,20)
