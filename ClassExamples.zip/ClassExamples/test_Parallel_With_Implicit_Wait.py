import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By


class TestLogin:
    def test_login_chrome(self):
        from selenium.webdriver.chrome.service import Service
        self.serv_obj = Service("C:/drivers/chromedriver.exe")

        self.driver = webdriver.Chrome(service=self.serv_obj)

        self.driver.implicitly_wait(10)

        self.driver.get("https://opensource-demo.orangehrmlive.com/")
        self.driver.find_element(By.NAME, "username").send_keys("Admin")
        self.driver.find_element(By.NAME, "password").send_keys("admin123")
        self.driver.find_element(By.TAG_NAME, "button").click()  # Signin
        assert self.driver.title == "OrangeHRM"
        self.driver.quit()


    def test_login_edge(self):
        from selenium.webdriver.edge.service import Service

        self.serv_obj  = Service("C:/drivers/msedgedriver.exe")
        self.driver = webdriver.Edge(service=self.serv_obj)

        self.driver.implicitly_wait(10)

        self.driver.get("https://opensource-demo.orangehrmlive.com/")
        self.driver.find_element(By.NAME, "username").send_keys("Admin")
        self.driver.find_element(By.NAME, "password").send_keys("admin123")
        self.driver.find_element(By.TAG_NAME, "button").click()  # Signin
        assert self.driver.title == "OrangeHRM"
        self.driver.quit()

    def test_login_firefox(self):
        from selenium.webdriver.firefox.service import Service

        self.serv_obj = Service("C:/drivers/geckodriver.exe")
        self.driver = webdriver.Firefox(service=self.serv_obj)

        self.driver.implicitly_wait(10)

        self.driver.get("https://opensource-demo.orangehrmlive.com/")
        self.driver.find_element(By.NAME, "username").send_keys("Admin")
        self.driver.find_element(By.NAME, "password").send_keys("admin123")
        self.driver.find_element(By.TAG_NAME, "button").click()  # Signin
        assert self.driver.title == "OrangeHRM"
        self.driver.quit()

