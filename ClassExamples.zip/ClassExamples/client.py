import sys
sys.path.append("C:/Users/admin/PycharmProjects/Pythontraining/day9/pack1")

#Apprach1
# import module1
# import module2
#
# module1.display()
# module2.show()

#Appraoch2
from module1 import *
from module2 import *

display()
show()



