from selenium import webdriver
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options

chrome_options = Options()
chrome_options.add_argument("--disable-notifications")

# Initialize driver with options
driver = webdriver.Chrome(
    service=ChromeService(ChromeDriverManager().install()),
    options=chrome_options
)

driver.implicitly_wait(10)

#Edge
# serv_obj=Service("C:\Drivers\edgedriver_win64\msedgedriver.exe")
# driver=webdriver.Edge(service=serv_obj)

driver.implicitly_wait(10)

driver.get("https://www.bestbuy.com/?intl=nosplash")
driver.maximize_window()

#Approach1
try:
    signupbox=driver.find_element(By.XPATH,"//*[@id='widgets-view-email-modal-mount']/div/div/div[1]/div/div/div/div/button")
    if signupbox.is_displayed():
        signupbox.click() # this will close box
except Exception:
    print("Signup box not available")


#Approach2
# act=ActionChains(driver)
# act.send_keys(Keys.ESCAPE).perform()
