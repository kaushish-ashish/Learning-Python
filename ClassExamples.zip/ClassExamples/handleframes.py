import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options

chrome_options = Options()
chrome_options.add_argument("--disable-notifications")

# Initialize driver with options
driver = webdriver.Chrome(
    service=ChromeService(ChromeDriverManager().install()),
    options=chrome_options
)

driver.implicitly_wait(10)

driver.get("https://selectorshub.com/iframe-scenario/")
driver.maximize_window()

driver.switch_to.frame("pact1")
driver.find_element(By.ID,  "inp_val").send_keys("This is first iframe")

driver.switch_to.frame("pact2")
driver.find_element(By.ID,  "jex").send_keys("This is second iframe")

driver.switch_to.frame("pact3")
driver.find_element(By.ID,  "glaf").send_keys("This is third iframe")
driver.switch_to.default_content()  # go back to main page

