class Bird:
    def display(self):
        print("I like Parrot")