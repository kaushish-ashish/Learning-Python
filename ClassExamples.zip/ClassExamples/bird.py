def fly():
    print("Bird can fly")

def color():
    print("Bird is green")