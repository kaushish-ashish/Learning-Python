from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class TestLogin:
    def test_login_chrome(self):
        from selenium.webdriver.chrome.service import Service as ChromeService
        from selenium.webdriver.chrome.options import Options
        from webdriver_manager.chrome import ChromeDriverManager

        chrome_options = Options()
        chrome_options.add_argument("--disable-notifications")

        # Initialize driver with options
        driver = webdriver.Chrome(
            service=ChromeService(ChromeDriverManager().install()),
            options=chrome_options
        )
        driver.get("https://opensource-demo.orangehrmlive.com/")

        wait = WebDriverWait(driver, 10)

        wait.until(EC.visibility_of_element_located((By.NAME, "username"))).send_keys("Admin")
        wait.until(EC.visibility_of_element_located((By.NAME, "password"))).send_keys("admin123")
        wait.until(EC.element_to_be_clickable((By.TAG_NAME, "button"))).click()

        wait.until(EC.title_contains("OrangeHRM"))
        assert "OrangeHRM" in driver.title

        driver.quit()


    def test_login_edge(self):
        from selenium.webdriver.edge.service import Service as EdgeService
        from selenium.webdriver.edge.options import Options as EdgeOptions
        edge_options = EdgeOptions()
        edge_options.add_argument("--disable-notifications")
        edge_options.add_argument("--start-maximized")

        serv_obj = EdgeService("C:/drivers/msedgedriver.exe")
        driver = webdriver.Edge(service=serv_obj,options=edge_options)
        wait = WebDriverWait(driver, 15)

        driver.get("https://opensource-demo.orangehrmlive.com/")

        # Username
        (wait.until
        (EC.visibility_of_element_located((By.XPATH, "//input[@placeholder='Username']"))).send_keys("Admin"))

        # Password
        wait.until(
        EC.visibility_of_element_located((By.XPATH, "//input[@placeholder='Password']"))).send_keys("admin123")

        # Login button
        wait.until(EC.element_to_be_clickable((By.TAG_NAME, "button"))).click()

        # Title validation
        wait.until(EC.title_contains("OrangeHRM"))
        assert "OrangeHRM" in driver.title

        driver.quit()

    def test_login_firefox(self):
        from selenium.webdriver.firefox.service import Service as FirefoxService
        from selenium.webdriver.firefox.options import Options as FirefoxOptions
        from webdriver_manager.firefox import GeckoDriverManager

        firefox_options = FirefoxOptions()
        firefox_options.set_preference("dom.webnotifications.enabled", False)

        driver = (webdriver.Firefox
                  (service=FirefoxService(GeckoDriverManager().install()),options=firefox_options))

        driver.get("https://opensource-demo.orangehrmlive.com/")

        wait = WebDriverWait(driver, 15)

        # Username
        wait.until(
        EC.visibility_of_element_located((By.XPATH, "//input[@placeholder='Username']"))).send_keys("Admin")

        # Password
        wait.until(
        EC.visibility_of_element_located((By.XPATH, "//input[@placeholder='Password']"))).send_keys("admin123")

        # Login button
        wait.until(EC.element_to_be_clickable((By.TAG_NAME, "button"))).click()

        # Validate successful login
        wait.until(EC.title_contains("OrangeHRM"))
        assert "OrangeHRM" in driver.title

        driver.quit()