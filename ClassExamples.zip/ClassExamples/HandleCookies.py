from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

chrome_options = Options()
chrome_options.add_argument("--disable-notifications")

# Initialize driver with options
driver = webdriver.Chrome(
    service=ChromeService(ChromeDriverManager().install()),
    options=chrome_options
)

driver.get("https://demo.nopcommerce.com/")
driver.maximize_window()

#Capture Cookies from the browser
cookies=driver.get_cookies()
print("Size of cookies:",len(cookies)) #6

# #Print details of all cookies
# for c in cookies:
#     #print(c)
#     print(c.get('name'),":",c.get('value'))
#
#
# #Add new cookie to the browser
# driver.add_cookie({"name":"MyCookie", "value":"123456"})
# cookies=driver.get_cookies()
# print("Size of cookies after adding new one:",len(cookies)) #7
#
# #Delete specific cookie from the browser
# driver.delete_cookie("MyCookie")
# cookies=driver.get_cookies()
# print("Size of cookies after deleted one:",len(cookies)) #6
#
#Delete all the cookies
driver.delete_all_cookies()
cookies=driver.get_cookies()
print("Size of cookies after deleted all:",len(cookies)) #1

driver.quit()




