def show():
    print("this is show function from module2")