import time
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options

chrome_options = Options()
chrome_options.add_argument("--disable-notifications")

# Initialize driver with options
driver = webdriver.Chrome(
    service=ChromeService(ChromeDriverManager().install()),
    options=chrome_options
)

driver.implicitly_wait(10)

driver.get("https://testautomationpractice.blogspot.com/")

driver.find_element(By.XPATH,"//input[@id='Wikipedia1_wikipedia-search-input']").send_keys("testing")
driver.find_element(By.XPATH,"//input[@type='submit']").click()

search_links=driver.find_elements(By.XPATH,"//div[@id='Wikipedia1_wikipedia-search-results']//div/a")
print("Number of links:",len(search_links))

print("printing and clicking on links...............")
for link in search_links:
    print(link.text)
    link.click()

#After opening all the pages, capture window id's
windowIds=driver.window_handles

print("Switching to each browser window and getting the titles........")
for window_id in windowIds:
    driver.switch_to.window(window_id)
    print(driver.title)

driver.quit()