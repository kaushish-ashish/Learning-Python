#test_Payments

class TestPayments:
    def test_paymentinDollor(self,setup):
        print("This is payment in dollor method..")
        assert True==True

    def test_paymentinRupees(self,setup):
        print("This is payment in rupees method..")
        assert True == True
