import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options

chrome_options = Options()
chrome_options.add_argument("--disable-notifications")

# Initialize driver with options
driver = webdriver.Chrome(
    service=ChromeService(ChromeDriverManager().install()),
    options=chrome_options
)

driver.implicitly_wait(10)

driver.get("https://www.countries-ofthe-world.com/flags-of-the-world.html")
driver.maximize_window()

# 1. Scroll down page by pixel
# driver.execute_script("window.scrollBy(0,3000)","")
# value=driver.execute_script("return window.pageYOffset;")
# print("Number of pixels moved:",value) #3000

#2. Scroll down page till the element is visible
flag=driver.find_element(By.XPATH,"//img[@alt='Flag of India']")
driver.execute_script("arguments[0].scrollIntoView();",flag)
value=driver.execute_script("return window.pageYOffset;")
print("Number of pixels moved:",value) #7539.33349609375

#3.scroll down page till end
# driver.execute_script("window.scrollBy(0,document.body.scrollHeight)")
# value=driver.execute_script("return window.pageYOffset;")
# print("Number of pixels moved:",value) #5990.8330078125
#
# time.sleep(5)
# #Scroll up to starting position
# driver.execute_script("window.scrollBy(0,-document.body.scrollHeight)")
# value=driver.execute_script("return window.pageYOffset;")
# print("Number of pixels moved:",value) #0
#
# time.sleep(5)