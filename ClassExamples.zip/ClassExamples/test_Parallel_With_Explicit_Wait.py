import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class TestLogin:

    def test_login_chrome(self):
        from selenium.webdriver.chrome.service import Service

        serv_obj = Service("C:/drivers/chromedriver.exe")
        driver = webdriver.Chrome(service=serv_obj)

        driver.get("https://opensource-demo.orangehrmlive.com/")
        wait = WebDriverWait(driver, 15)

        wait.until(EC.visibility_of_element_located((By.NAME, "username"))).send_keys("Admin")
        wait.until(EC.visibility_of_element_located((By.NAME, "password"))).send_keys("admin123")
        wait.until(EC.element_to_be_clickable((By.TAG_NAME, "button"))).click()

        wait.until(EC.title_contains("OrangeHRM"))
        assert "OrangeHRM" in driver.title

        driver.quit()

    def test_login_edge(self):
        from selenium.webdriver.edge.service import Service

        serv_obj = Service("C:/drivers/msedgedriver.exe")
        driver = webdriver.Edge(service=serv_obj)

        driver.get("https://opensource-demo.orangehrmlive.com/")
        wait = WebDriverWait(driver, 15)

        wait.until(EC.visibility_of_element_located((By.NAME, "username"))).send_keys("Admin")
        wait.until(EC.visibility_of_element_located((By.NAME, "password"))).send_keys("admin123")
        wait.until(EC.element_to_be_clickable((By.TAG_NAME, "button"))).click()

        wait.until(EC.title_contains("OrangeHRM"))
        assert "OrangeHRM" in driver.title

        driver.quit()

    def test_login_firefox(self):
        from selenium.webdriver.firefox.service import Service

        serv_obj = Service("C:/drivers/geckodriver.exe")
        driver = webdriver.Firefox(service=serv_obj)

        driver.get("https://opensource-demo.orangehrmlive.com/")
        wait = WebDriverWait(driver, 15)

        wait.until(EC.visibility_of_element_located((By.NAME, "username"))).send_keys("Admin")
        wait.until(EC.visibility_of_element_located((By.NAME, "password"))).send_keys("admin123")
        wait.until(EC.element_to_be_clickable((By.TAG_NAME, "button"))).click()

        wait.until(EC.title_contains("OrangeHRM"))
        assert "OrangeHRM" in driver.title

        driver.quit()
