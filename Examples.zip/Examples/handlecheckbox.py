from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

chrome_options = Options()
chrome_options.add_argument("--disable-notifications")

# Initialize driver with options
driver = webdriver.Chrome(
    service=ChromeService(ChromeDriverManager().install()),
    options=chrome_options
)

driver.implicitly_wait(10)
driver.get("https://testautomationpractice.blogspot.com/")
driver.maximize_window()

element = driver.find_element(By.XPATH, "//label[normalize-space()='Days:']")
driver.execute_script("arguments[0].scrollIntoView();", element)

# 1) select specific checkbox
# driver.find_element(By.XPATH,"//input[@id='monday']").click()
# print("Checkbox selected successfully")

#2) select all the checkboxes
checkboxes=driver.find_elements(By.XPATH,"//input[@type='checkbox' and contains(@id,'day')]")
# print(len(checkboxes)) #7

#Appraoch1
# for i in range(len(checkboxes)):
#     checkboxes[i].click()

#Appraoch2
for checkbox in checkboxes:
    checkbox.click() #7
print("All the Checkboxes selected successfully")

#3) select multiple checkboxes by choice
# for checkbox in checkboxes:
#     week_name=checkbox.get_attribute('id')
#     if week_name=='monday' or week_name=='sunday':
#         checkbox.click()
# print("Checkboxes selected successfully")

#4 ) select last 2 checkboxes
#range(5,7) -->6,7
# totalnumberofelements-2=starting index
# for i in range(len(checkboxes)-2,len(checkboxes)):
#     checkboxes[i].click()

#5) select first 2 checkboxes
# for i in range(len(checkboxes)):
#     if i<2:
#         checkboxes[i].click()

#6) clearing all the check boxes
for checkbox in checkboxes:
    if checkbox.is_selected():
        checkbox.click()
print("All the Checkboxes unselected successfully")

driver.quit()