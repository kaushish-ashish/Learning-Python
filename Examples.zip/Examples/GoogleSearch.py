from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

chrome_options = Options()
chrome_options.add_argument("--disable-notifications")

# Initialize driver with options
driver = webdriver.Chrome(
    service=ChromeService(ChromeDriverManager().install()),
    options=chrome_options
)

driver.implicitly_wait(10)

driver.get("http://www.google.com")
driver.maximize_window()

driver.find_element(By.NAME,"q").send_keys("selenium") #searchbox
search_items=driver.find_elements(By.XPATH,"(//ul[@role='listbox'])[1]//li")

print(len(search_items))

for item in search_items:
    print(item.text)
    if item.text=='selenium':
        item.click()
        break