import time

from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.support.select import Select
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By

chrome_options = Options()
chrome_options.add_argument("--disable-notifications")

# Initialize driver with options
driver = webdriver.Chrome(
    service=ChromeService(ChromeDriverManager().install()),
    options=chrome_options
)

driver.implicitly_wait(5)
driver.get("https://testautomationpractice.blogspot.com/")
driver.maximize_window()


element = driver.find_element(By.XPATH, "//label[normalize-space()='Country:']")
driver.execute_script("arguments[0].scrollIntoView();", element)

#drpcountry_ele=driver.find_element(By.XPATH,"//select[@id='input-country']")
drp_country=Select(driver.find_element(By.XPATH,"//select[@id='country']"))

# select option from the dropdown
# drp_country.select_by_visible_text("United Kingdom")
# drp_country.select_by_value("france")  #France
# drp_country.select_by_index(5)  # index


# capture all the options and print them
all_options=drp_country.options
print("total number of options:",len(all_options))
#
# for opt in all_options:
#     print(opt.text)

# select option from dropdown without using built-in method
# for opt in all_options:
#     if opt.text=="India":
#         opt.click()
#         break
time.sleep(5)
all_Options=driver.find_elements(By.XPATH,'//*[@id="country"]/option')
print(len(all_Options))
